require_relative 'piece'

class Pawn <  Piece
    
    def initialize
        super
    end

    def symbol
        :pawn
    end

    def moves
        row, col = pos
        if color == :white
            row -= 1
            @grid.move_pos(:white, pos, [row, col])
        end
        if color == :black
            row += 1
            @grid.move_pos(:black, pos, [row,col])
        end
    end
    
    private
    def at_start_row?
        row, col = pos
        if color == black
            return true if row == 1
        else
            return true if row == 6
        end
        false
    end
    private
    def forward_dir
        #return 1 or -1
        if color == :white
            return -1
        else
            return 1
        end
    end

    private
    def forward_steps
        possible_steps = []
        row, col = pos
        if at_start_row?
            possible_steps << [forward_dir * 2 + row, col]
        end
        possible_steps << [forward_dir + row, col]
        possible_steps
    end

    private
    def side_attacks
        possible_side_attacks = []
        color == :black ? opposite_color = :white : opposite_color = :black
        row, col = pos
        unless @grid[forward_dir + row][col+1].color == opposite_color
            new_pos = [forward_dir+row, col+1]
            possible_side_attacks << [new_pos]
        end
        unless @grid[forward_dir + row][col-1] == opposite_color
            new_pos = [forward_dir+row, col-1]
            possible_side_attacks << [new_pos]
        end
        possible_side_attacks
        
    end
end