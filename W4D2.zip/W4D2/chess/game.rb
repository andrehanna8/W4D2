require_relative 'board'
require_relative 'display'
require_relative 'player'
class Game

    def initialize
        @board = Board.new
        @display = Display.new
        @players = {}
        @current_player = nil
    end

    def play
    
    end

    private
    def notify_players

    end

    private
    def swap_turn

    end

end