require_relative 'piece'
require_relative 'stepable'

class Knight <  Piece
    include Stepable
    DIRECTIONS = [[2, 1], [-2, 1], [2, -1],[-2, -1], [1, 2], [-1, 2], [1, -2], [-1, -2]] #[2,1]
    def initialize
        super
    end

    def symbol
        :knight
    end

    protected
    def move_diffs
        row, col = pos
        possible_positions = []
        (0...DIRECTIONS.length).each do |i|
            curr_subarr = DIRECTIONS[i]
            first = curr_subarr[0] #= 2
            second = curr_subarr[1] #= 1
            new_pos = [first + row, second + col]
            possible_positions << new_pos if new_pos.all? { |ele| ele >= 0 && ele <= 7 } and @grid
        end
    end

end