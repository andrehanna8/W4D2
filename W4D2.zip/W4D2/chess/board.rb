class Board

    #rook, knight, bishop, queen, king, bishop, knight, rook

    def initialize

        @grid = []
        
        (0...8).each do |i|
            (0...8).each do |j|
                if i <= 1 or i >= 6
                    grid[i][j] = Piece.new
                else
                    grid[i][j] = self.null_piece
                end
            end
        end

    end

    def [](pos)
        row, col = pos
        @rows[row][col]
    end

    def []=(pos, piece)
        row, col = pos
        @rows[row][col] = piece
    end

    def move_piece(color, start_pos, end_pos)
        raise "starting position error" if grid[start_pos].is_a?(NullPiece)
        if !grid[start_pos].is_a?(NullPiece) or color == grid[end_pos].color
            raise "ending position error" 
        end
        if grid[end_pos].is_a?(NullPiece)
            grid[start_pos], grid[end_pos] = grid[end_pos], grid[start_pos]
        else
            grid[end_pos] = grid[start_pos], grid[start_pos] = self.null_piece
        end
    end
        

    def valid_pos?(pos)

    end

    def add_piece(piece, pos)

    end

    def checkmate?(color)

    end

    def in_check?(color)

    end

    def find_king(color)

    end

    def pieces

    end

    def dup 

    end

    def move_piece!(color, start_pos, end_pos)

    end
end