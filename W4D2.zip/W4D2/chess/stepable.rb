module Stepable

    def moves

    end

    def move_diffs

    end

end