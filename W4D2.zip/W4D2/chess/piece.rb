class Piece
    attr_reader :color, :pos, :board
    def initialize(color, board, pos)
        @color = color
        @board = board
        @pos = []
    end

    def to_s
        symbol.name
    end

    def empty?
        @color == nil
    end

    def valid_moves

    end

    def pos=(val)
        @pos = val
    end

    def symbol
        :piece
    end

    def move_into_check?(end_pos)

    end
end