require_relative "player"
require_relative "board"

class ComputerPlayer < Player
    def make_move()

    end
end