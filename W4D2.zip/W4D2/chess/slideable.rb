require_relative 'board'

module Slideable
    HORIZONTAL_DIRS = []
    DIAGONAL_DIRS = []

    def horizontal_dirs
        move_vertically(1)
        move_vertically(-1)
        move_horizontally(1)
        move_horizontally(-1)
        HORIZONTAL_DIRS
    end

    def move_vertically(dir)
        row, col = pos
        @grid[pos].color == :black ? opposite_color = :white : opposite_color = :black
        while new_row < @grid.size and new_row > 0 
            new_row += dir
            position = grow_unblocked_moves_in_dir(new_row, col)
            unless position.nil?
                HORIZONTAL_DIRS << position
                break if @grid[new_row][col].color != opposite_color
            else
                break
            end
        end
        HORIZONTAL_DIRS
    end

    def move_horizontally(dir)
        row, col = pos
        @grid[pos].color == :black ? opposite_color = :white : opposite_color = :black
        new_col = col
        while new_col > 0 and new_col < @grid.size
            new_col += dir
            position = grow_unblocked_moves_in_dir(row, new_col)
            unless position.nil?
                HORIZONTAL_DIRS << position
                break if @grid[row][new_col].color != opposite_color
            else
                break
            end
        end
        HORIZONTAL_DIRS
    end

    def diagonal_dirs
        move_diagonally(-1,-1)
        move_diagonally(-1,1)
        move_diagonally(1, -1)
        move_diagonally(1,1)
        DIAGONAL_DIRS
    end

    def move_diagonally(dir_r, dir_c)
        new_row = row
        new_col = col
        @grid[pos].color == :black ? opposite_color = :white : opposite_color = :black
        while new_row > 0 and new_row < @grid.size and new_col > 0 and new_col < @grid.size
            new_row += dir_r
            new_col += dir_c
            position = grow_unblocked_moves_in_dir(new_row, new_col)
            unless position.nil?
                DIAGONAL_DIRS << position
                break if @grid[new_row][new_col].color != opposite_color
            else
                break
            end
        end
        DIAGONAL_DIRS
    end

    def moves
        horizontal_dirs + diagonal_dirs
    end

    private 
    def move_dirs

    end

    private 
    def grow_unblocked_moves_in_dir(dx,dy)
        if @grid[new_row][new_col] == @grid.null_piece or @grid[new_row][new_col].color != opposite_color
            return [new_row, new_col]
        end
        nil
    end
    

end