require_relative "player"
require_relative "board"

class HumanPlayer < Player
    def make_move()

    end
end