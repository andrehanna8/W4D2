require_relative 'piece'
require_relative 'slideable'

class Bishop <  Piece
    include Slideable

    def initialize
        super
    end

    def symbol
        :bishop
    end

    private
    def move_dirs
        diagonal_dirs
    end

end